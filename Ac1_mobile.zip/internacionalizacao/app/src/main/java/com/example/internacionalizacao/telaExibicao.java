package com.example.internacionalizacao;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class telaExibicao extends AppCompatActivity {

    private ListView listViewHabitos;
    private Button btnAdicionarHabito;
    private BancoHelper databaseHelper;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> listaHabitos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_exibicao);

        listViewHabitos = findViewById(R.id.listViewHabitos);
        btnAdicionarHabito = findViewById(R.id.btnAdicionarHabito);
        databaseHelper = new BancoHelper(this);

        btnAdicionarHabito.setOnClickListener(v -> {
            Intent intent = new Intent(telaExibicao.this, MainActivity.class);
            startActivity(intent);
        });

        carregarHabitos();
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarHabitos(); //
    }

    private void carregarHabitos() {
        Cursor cursor = databaseHelper.listarHabitos();
        listaHabitos = new ArrayList<>();
        String hoje = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        if (cursor.moveToFirst()) {
            do {
                String nome = cursor.getString(1);
                String data = cursor.getString(2);

                String status = hoje.equals(data) ? "\uD83D\uDC4D" : "\uD83D\uDC4E";
                listaHabitos.add(nome + " - " + status);
            } while (cursor.moveToNext());
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaHabitos);
        listViewHabitos.setAdapter(adapter);
    }
}
