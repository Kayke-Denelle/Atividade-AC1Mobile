package com.example.internacionalizacao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BancoHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "meubanco.db";
    private static final int VERSAO = 3;

    public BancoHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE habitos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome TEXT NOT NULL, " +
                "data TEXT, " +  // Adicionando a coluna 'data'
                "feitoHoje INTEGER DEFAULT 0" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS habitos");
        onCreate(db);
    }

    public long inserirHabito(String nome) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("nome", nome);
        return db.insert("habitos", null, valores);
    }

    public int atualizarHabito(int id, String nome) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("nome", nome);
        return db.update("habitos", valores, "id = ?", new String[]{String.valueOf(id)});
    }

    public int excluirHabito(int id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("habitos", "id = ?", new String[]{String.valueOf(id)});
    }

    public Cursor listarHabitos() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT * FROM habitos", null);
    }

    public int marcarHabitoComoFeito(int id, String data) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        if (data != null) {
            values.put("data", data);
        } else {
            values.putNull("data");
        }

        return db.update("habitos", values, "id = ?", new String[]{String.valueOf(id)});
    }
}
