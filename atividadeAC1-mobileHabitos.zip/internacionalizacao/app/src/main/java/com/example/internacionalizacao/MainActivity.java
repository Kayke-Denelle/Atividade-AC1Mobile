package com.example.internacionalizacao;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText edtNome;
    private Button btnSalvar;
    private ListView listViewHabitos;
    private BancoHelper databaseHelper;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> listaHabitos;
    private ArrayList<Integer> listaIds;
    private int habitoId = -1;

    private Button btnVoltar;

    private Button btnFeito;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNome = findViewById(R.id.edtNome);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnSalvar = findViewById(R.id.btnSalvar);
        listViewHabitos = findViewById(R.id.listViewHabitos);
        databaseHelper = new BancoHelper(this);


        btnVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, telaExibicao.class);
            startActivity(intent);
        });

        carregarHabitos();

        btnSalvar.setOnClickListener(v -> {
            String nome = edtNome.getText().toString();

            if (btnSalvar.getText().equals("Salvar")) {
                if (!nome.isEmpty()) {
                    long resultado = databaseHelper.inserirHabito(nome);
                    if (resultado != -1) {
                        Toast.makeText(this, "Hábito salvo!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                        carregarHabitos();
                    } else {
                        Toast.makeText(this, "Erro ao salvar!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Informe o nome do hábito!", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (!nome.isEmpty()) {
                    int resultado = databaseHelper.atualizarHabito(habitoId, nome);
                    if (resultado > 0) {
                        Toast.makeText(this, "Hábito atualizado!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                        btnSalvar.setText("Salvar");
                        carregarHabitos();
                    } else {
                        Toast.makeText(this, "Erro ao atualizar!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnFeito = findViewById(R.id.btnFeito);

        btnFeito.setOnClickListener(v -> {
            if (habitoId > 0) {
                String hoje = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                int feito = databaseHelper.marcarHabitoComoFeito(habitoId, hoje);
                if (feito > 0) {
                    Toast.makeText(this, "Hábito marcado como feito!", Toast.LENGTH_SHORT).show();
                    carregarHabitos();
                } else {
                    Toast.makeText(this, "Erro ao marcar como feito.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Selecione um hábito primeiro!", Toast.LENGTH_SHORT).show();
            }
        });

        listViewHabitos.setOnItemClickListener((parent, view, position, id) -> {
            habitoId = listaIds.get(position);
            String[] partes = listaHabitos.get(position).split(" - ");
            edtNome.setText(partes[1]);
            btnSalvar.setText("Atualizar");
        });

        listViewHabitos.setOnItemLongClickListener((adapterView, view1, pos, l) -> {
            int idHabito = listaIds.get(pos);
            int deletado = databaseHelper.excluirHabito(idHabito);
            if (deletado > 0) {
                Toast.makeText(this, "Hábito excluído!", Toast.LENGTH_SHORT).show();
                limparCampos();
                habitoId = -1;
                carregarHabitos();
            }
            return true;
        });
    }

    private void carregarHabitos() {
        Cursor cursor = databaseHelper.listarHabitos();
        listaHabitos = new ArrayList<>();
        listaIds = new ArrayList<>();
        String hoje = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String nome = cursor.getString(1);
                String data = cursor.getString(2);

                String status = hoje.equals(data) ? "\uD83D\uDC4D" : "\uD83D\uDC4E";
                listaHabitos.add(id + " - " + nome + " - " + status);
                listaIds.add(id);
            } while (cursor.moveToNext());
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaHabitos);
        listViewHabitos.setAdapter(adapter);
    }

    private void limparCampos() {
        edtNome.setText("");
        btnSalvar.setText("Salvar");
        habitoId = -1;
    }
}
